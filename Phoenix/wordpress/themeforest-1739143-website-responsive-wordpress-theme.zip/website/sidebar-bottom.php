<?php
/**
 * @package WordPress
 * @subpackage Website_Theme
 * @since Website 1.0
 */
?>

<aside id="aside-bottom" class="clear">
	<ul>
		<?php dynamic_sidebar('sidebar-bottom'); ?>
	</ul>
</aside>