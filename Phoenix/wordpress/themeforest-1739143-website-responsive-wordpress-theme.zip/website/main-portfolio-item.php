<?php
/**
 * @package WordPress
 * @subpackage Website_Theme
 * @since Website 1.2
 */
?>

<section class="main">
	<?php
		$hide = Website::getInheritOption('options/title', 'portfolio-item/hide_title');
		if (is_search() || $hide === false || $hide === 'show') {
			get_template_part('title', 'portfolio-item');
		}
	?>
	<?php get_template_part('content', 'portfolio-item'); ?>
</section>