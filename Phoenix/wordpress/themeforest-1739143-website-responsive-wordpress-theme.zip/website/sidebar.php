<?php
/**
 * @package WordPress
 * @subpackage Website_Theme
 * @since Website 1.0
 */
?>

<?php if ($sidebar = Website::getSidebarName()): ?>
	<aside id="aside" class="<?php echo Website::getThemeOption('appearance/sidebar') == 'right' ? 'beta' : 'alpha'; ?>">
		<ul>
			<?php dynamic_sidebar('sidebar-'.$sidebar); ?>
		</ul>
	</aside>
<?php endif; ?>