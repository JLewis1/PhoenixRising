<?php
/**
 * @package WordPress
 * @subpackage Website_Theme
 * @since Website 2.0
 */
?>

<section class="main">
	<?php
		$hide = Website::getInheritOption('options/title', 'portfolio/hide_title');
		if ($hide === false || $hide === 'show') {
			get_template_part('title', 'portfolio');
		}
	?>
	<?php get_template_part('content', 'portfolio'); ?>
</section>