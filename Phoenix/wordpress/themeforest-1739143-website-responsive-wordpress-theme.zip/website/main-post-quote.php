<?php
/**
 * @package WordPress
 * @subpackage Website_Theme
 * @since Website 1.2
 */
?>

<section class="main">
	<?php get_template_part('title', 'post'); ?>
	<?php get_template_part('content', 'post'); ?>
</section>