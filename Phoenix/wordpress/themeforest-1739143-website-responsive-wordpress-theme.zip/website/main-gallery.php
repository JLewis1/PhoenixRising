<?php
/**
 * @package WordPress
 * @subpackage Website_Theme
 * @since Website 2.0
 */
?>

<section class="main">
	<?php
		$hide = Website::getInheritOption('options/title', 'gallery/hide_title');
		if ($hide === false || $hide === 'show') {
			get_template_part('title', 'gallery');
		}
	?>
	<?php get_template_part('content', 'gallery'); ?>
</section>